﻿namespace services
{
    internal class AddDbContext<T>
    {
    }
}