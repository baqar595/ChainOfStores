﻿namespace ChainOfStores
{
    internal class _config
    {
    }
}