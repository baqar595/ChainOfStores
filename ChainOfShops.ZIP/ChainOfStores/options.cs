﻿namespace ChainOfStores
{
    internal class options
    {
    }
}