
using Shop.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ChainOfStores
{
    public class CreateProduct

    {
        private ApplicationDbContext _context;

        public CreateProduct(ApplicationDbContext context)
        {
            _context = context; 
        }
        public void Do(int id,string Name ,string Description )
        {
            _context.products.Add(new Product { 
                Id = id, Name = Name, Description = Description
           });
        }
    }
}
