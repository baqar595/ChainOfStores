﻿namespace ChainOfStores
{
    public class ApplicationDbContext
    {
        internal object products;
    }
}